from scapy.all import Ether, ARP, srp, IP, TCP, sr, conf
import socket
import time
import json
import csv
from concurrent.futures import ThreadPoolExecutor


# =====================================================
# UTILIDADES
# =====================================================
def obtener_red_local():
    try:
        ip_local = conf.route.route("0.0.0.0")[1]
        base = ".".join(ip_local.split(".")[:-1])
        return f"{base}.0/24"
    except Exception:
        return "192.168.1.0/24"


def parse_puertos(puertos):
    if puertos is None:
        return [22, 80, 443]

    if isinstance(puertos, str):
        return [int(p.strip()) for p in puertos.split(",") if p.strip().isdigit()]

    return list(puertos)


# =====================================================
# MAC VENDOR (ligero, sin dependencias externas)
# =====================================================
VENDOR_DB = {
    "00:1A:79": "Apple",
    "44:38:39": "Samsung",
    "DC:A6:32": "Intel",
    "FC:FB:FB": "IoT/Router"
}


def get_vendor(mac):
    oui = mac.upper().replace("-", ":")[:8]
    return VENDOR_DB.get(oui, "Desconocido")


# =====================================================
# OS GUESS
# =====================================================
def guess_os(ttl):
    if ttl <= 64:
        return "Linux/Unix"
    elif ttl <= 128:
        return "Windows"
    return "Unknown"


# =====================================================
# RISK SCORE
# =====================================================
def risk_score(ports):
    score = 0
    for p in ports:
        if p == 22:
            score += 2
        elif p == 23:
            score += 4
        elif p == 445:
            score += 5
        elif p == 3389:
            score += 4
        else:
            score += 1
    return score


# =====================================================
# ARP SCAN (MEJORADO CON VENDOR)
# =====================================================
def arp_scan(rango_red=None, timeout=3):
    rango_red = rango_red or obtener_red_local()

    pkt = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=rango_red)
    ans, _ = srp(pkt, timeout=timeout, verbose=0)

    hosts = []

    print(f"[+] Escaneando red: {rango_red}")

    for _, r in ans:
        host = {
            "ip": r.psrc,
            "mac": r.hwsrc,
            "vendor": get_vendor(r.hwsrc)
        }

        hosts.append(host)
        print(f"[✔] {host['ip']} ({host['mac']}) - {host['vendor']}")

    return hosts


# =====================================================
# BANNER GRABBING
# =====================================================
def detectar_servicio(ip, puerto):
    try:
        s = socket.socket()
        s.settimeout(1)
        s.connect((ip, puerto))
        data = s.recv(1024).decode(errors="ignore")
        s.close()
        return data.strip()
    except:
        return ""


# =====================================================
# SCAN POR HOST
# =====================================================
def scan_puertos_ip(host, puertos, timeout=1, banner=False):
    ip = host["ip"]

    abiertos = []
    servicios = {}
    ttl_seen = 0

    try:
        pkt = IP(dst=ip) / TCP(dport=puertos, flags="S")
        ans, _ = sr(pkt, timeout=timeout, verbose=0)

        for _, r in ans:
            if r.haslayer(TCP) and r[TCP].flags == 0x12:
                p = r[TCP].sport
                abiertos.append(p)

                sr(IP(dst=ip) / TCP(dport=p, flags="R"), timeout=0.5, verbose=0)

                if banner:
                    servicios[p] = detectar_servicio(ip, p)

            if r.haslayer(IP):
                ttl_seen = r[IP].ttl

    except:
        pass

    return {
        "ip": ip,
        "mac": host.get("mac"),
        "vendor": host.get("vendor"),
        "os_guess": guess_os(ttl_seen),
        "open_ports": abiertos,
        "services": servicios,
        "risk": risk_score(abiertos),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }


# =====================================================
# SCAN PARALELO
# =====================================================
def syn_scan(hosts, puertos=None, threads=10, detectar_banner=False):
    puertos = parse_puertos(puertos)

    print("[+] Iniciando SYN scan...")

    results = []

    with ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [
            ex.submit(scan_puertos_ip, h, puertos, 1, detectar_banner)
            for h in hosts
        ]

        for f in futures:
            r = f.result()
            print(f"[✔] {r['ip']} ({r['vendor']}) → {r['open_ports']}")
            results.append(r)

    return results


# =====================================================
# EXPORT CSV
# =====================================================
def exportar_csv(resultados, puertos, archivo="scan.csv"):
    puertos = parse_puertos(puertos)

    with open(archivo, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["IP", "MAC", "VENDOR", "OS", "RISK"] + [str(p) for p in puertos])

        for r in resultados:
            w.writerow(
                [r["ip"], r.get("mac"), r.get("vendor"), r.get("os_guess"), r.get("risk")] +
                ["1" if p in r["open_ports"] else "0" for p in puertos]
            )


# =====================================================
# EXPORT JSON
# =====================================================
def exportar_json(resultados, archivo="scan.json"):
    with open(archivo, "w") as f:
        json.dump(resultados, f, indent=4)


# =====================================================
# EXPORT HTML (simple)
# =====================================================
def exportar_html(resultados, archivo="scan.html"):
    html = "<html><body><h2>Scan Report</h2><table border='1'>"
    html += "<tr><th>IP</th><th>MAC</th><th>Vendor</th><th>OS</th><th>Risk</th><th>Ports</th></tr>"

    for r in resultados:
        html += f"""
        <tr>
            <td>{r['ip']}</td>
            <td>{r.get('mac')}</td>
            <td>{r.get('vendor')}</td>
            <td>{r.get('os_guess')}</td>
            <td>{r.get('risk')}</td>
            <td>{','.join(map(str, r['open_ports']))}</td>
        </tr>
        """

    html += "</table></body></html>"

    with open(archivo, "w") as f:
        f.write(html)


# =====================================================
# API PRINCIPAL
# =====================================================
def scan_network(puertos=None, red=None, threads=10, banner=False):
    hosts = arp_scan(red)

    return syn_scan(
        hosts,
        puertos=puertos,
        threads=threads,
        detectar_banner=banner
    )