import SystemAuditModulepy as samp
import sys

def mostrar_menu():
    print("SCRIPT DE ESCANEO DE RED")
    print("1. Escanear red (ARP)")
    print("2. Escaneo SYN completo (puertos por defecto: 22,80,443)")
    print("3. Escaneo SYN con puertos personalizados")
    print("4. Escaneo SYN con captura de banners")
    print("5. Exportar resultados a CSV")
    print("6. Exportar resultados a JSON")
    print("7. Exportar resultados a HTML")
    print("8. Escanear y exportar a todos los formatos")
    print("9. Mostrar vendor de MAC específica")
    print("10. Calcular risk score de un host")
    print("0. Salir")

def scan_y_guardar(puertos=None, banner=False):
    print("\nIniciando escaneo")
    resultados = samp.scan_network(puertos=puertos, banner=banner)
    print(f"\nEscaneo completado. {len(resultados)} hosts encontrados.")
    return resultados

def pedir_puertos():
    entrada = input("Ingrese puertos separados por coma (ej: 22,80,443): ")
    if entrada.strip():
        return [int(p.strip()) for p in entrada.split(",") if p.strip().isdigit()]
    return None

def main():
    resultados_actuales = None
    
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción: ").strip()
        
        if opcion == "1":
            print("\nEjecutando ARP scan")
            hosts = samp.arp_scan()
            print(f"\nTotal hosts encontrados: {len(hosts)}")
            
        elif opcion == "2":
            resultados_actuales = scan_y_guardar()
            
        elif opcion == "3":
            puertos = pedir_puertos()
            resultados_actuales = scan_y_guardar(puertos=puertos)
            
        elif opcion == "4":
            puertos = pedir_puertos()
            resultados_actuales = scan_y_guardar(puertos=puertos, banner=True)
            
        elif opcion == "5":
            if resultados_actuales:
                archivo = input("Nombre del archivo CSV (default: scan.csv): ") or "scan.csv"
                puertos = pedir_puertos()
                samp.exportar_csv(resultados_actuales, puertos, archivo)
                print(f"Exportado a {archivo}")
            else:
                print("No hay resultados. Realice un escaneo primero (opción 2,3 o 4).")
                
        elif opcion == "6":
            if resultados_actuales:
                archivo = input("Nombre del archivo JSON (default: scan.json): ") or "scan.json"
                samp.exportar_json(resultados_actuales, archivo)
                print(f"Exportado a {archivo}")
            else:
                print("No hay resultados. Realice un escaneo primero (opción 2,3 o 4).")
                
        elif opcion == "7":
            if resultados_actuales:
                archivo = input("Nombre del archivo HTML (default: scan.html): ") or "scan.html"
                samp.exportar_html(resultados_actuales, archivo)
                print(f"Exportado a {archivo}")
            else:
                print("No hay resultados. Realice un escaneo primero (opción 2,3 o 4).")
                
        elif opcion == "8":
            if resultados_actuales:
                puertos = pedir_puertos()
                samp.exportar_csv(resultados_actuales, puertos, "scan.csv")
                samp.exportar_json(resultados_actuales, "scan.json")
                samp.exportar_html(resultados_actuales, "scan.html")
                print("Exportado a CSV, JSON y HTML")
            else:
                print("No hay resultados. Realice un escaneo primero (opción 2,3 o 4).")
                
        elif opcion == "9":
            mac = input("Ingrese dirección MAC (ej: 00:1A:79:XX:XX:XX): ")
            vendor = samp.get_vendor(mac)
            print(f"Vendor: {vendor}")
            
        elif opcion == "10":
            if resultados_actuales:
                ip = input("Ingrese la IP del host: ")
                for host in resultados_actuales:
                    if host["ip"] == ip:
                        print(f"Risk score para {ip}: {host['risk']}")
                        print(f"Puertos abiertos: {host['open_ports']}")
                        break
                else:
                    print("IP no encontrada en los resultados.")
            else:
                print("No hay resultados. Realice un escaneo primero (opción 2,3 o 4).")
                
        elif opcion == "0":
            print("Saliendo")
            sys.exit(0)
            
        else:
            print("Opción inválida. Intente de nuevo.")
        
        input("\nPresione Enter para continuar")

if __name__ == "__main__":
    main()