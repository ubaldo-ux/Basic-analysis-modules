Import-Module "$PSScriptRoot\SystemAuditModule.psm1" -Force
Clear-Host
$salir = $false
Write-Host '===Herramienta de analisis y auditoria en Powershell==='
while (-not $salir){
    Write-Host "1)  Ver Sistema, Disco y Software"
    Write-Host "2)  Ver Procesos"
    Write-Host "3)  Ver Redes y Conexiones"
    Write-Host "4)  Ver Usuarios y Privilegios"
    Write-Host "5)  Ver Seguridad del Sistema"
    Write-Host "6)  Ver Salud del Sistema"
    Write-Host "7)  Exportar auditoria completa (JSON + HTML)" 
    Write-Host "8)  Ver Log de auditoria" 
    Write-Host "9)  Limpiar Log" 
    Write-Host "10) Salir" 
    try {
        $opcion = Read-Host 'Ingresar opcion(1-10): '
        switch ($opcion) {
        '1' {
        Show-SystemInfo
        Pause
        Clear-Host
        }
        '2' {
        Show-ProcessesInfo
        Pause
        Clear-Host       
        }
        '3' {
        Show-NetworkInfo
        Pause
        Clear-Host
        }
        '4' {
        Show-UsersPrivileges
        Pause
        Clear-Host
        }
        '5' {
        Show-SecurityInfo           
        Pause
        Clear-Host
        }
        '6' {
        Show-SystemHealthInfo          
        Pause
        Clear-Host
        }
'7' {
    $saveDir = "$env:USERPROFILE\Desktop"
    $time = Get-Date -Format "yyyyMMdd_HHmm"
    $jsonPath = Join-Path $saveDir "SystemAudit_$time.json"
    
    Write-Host "Generando auditoria, esto puede tomar unos segundos..." -ForegroundColor Cyan
    
    Invoke-SystemAudit -OutputPath $jsonPath
    
    Write-Host "Auditoria completada" -ForegroundColor Green
    
    if (Test-Path $jsonPath) {
        Write-Host "JSON: $jsonPath" -ForegroundColor Gray
    }
    
    $htmlPath = [System.IO.Path]::ChangeExtension($jsonPath, "html")
    if (Test-Path $htmlPath) {
        Write-Host "HTML: $htmlPath" -ForegroundColor Gray
    }
    
    Pause
    Clear-Host
}
        '8' {
        $logPath = "$env:USERPROFILE\Desktop\SystemAudit.log"
        if (Test-Path $logPath) {
            Get-Content $logPath | Select-Object -Last 50
        } else {
            Write-Host "No hay log disponible" 
        }             
        Pause
        Clear-Host
        }
        '9' {
        $logPath = "$env:USERPROFILE\Desktop\SystemAudit.log"
        if (Test-Path $logPath) {
            Clear-Content $logPath
            Write-Host "Log limpiado correctamente" 
        } else {
            Write-Host "No existe archivo de log" 
        } 
        Pause
        Clear-Host
        }
        '10' {
        Write-Host 'Saliendo...'
        $salir = $true
        }
        default{
            Write-Host 'Opcion invalida'
        }
     }
    }
    catch {
        Write-Host "Error: $($_.Exception.Message)"
    }
    
}