# ================================
# SystemAuditModule.psm1
# ================================

$script:SystemCache = $null
$script:LogPath = "$env:USERPROFILE\Desktop\SystemAudit.log"

# ================================
# LOGGING
# ================================

function Write-AuditLog {
    param([string]$Message)
    try {
        Add-Content -Path $script:LogPath -Value "$(Get-Date -Format s) - $Message"
    }
    catch {
        # No se puede registrar, pero no rompemos el flujo
    }
}

# ================================
# SYSTEM
# ================================

function Get-SystemCache {
    if (-not $script:SystemCache) {
        try {
            $script:SystemCache = Get-ComputerInfo
            Write-AuditLog "Exito en Get-SystemCache"
        }
        catch {
            Write-AuditLog "Error en Get-SystemCache: $($_.Exception.Message)"
            $script:SystemCache = $null
        }
    }
    return $script:SystemCache
}

function Get-SystemDetails {
    [CmdletBinding()]
    param()

    try {
        $os = Get-SystemCache | Select-Object OSName, OSVersion, OsArchitecture
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue
        $ram = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue

        $drives = Get-PSDrive -PSProvider FileSystem | ForEach-Object {
            [PSCustomObject]@{
                DriveLetter = $_.Name
                FreeGB = [math]::Round($_.Free / 1GB, 2)
            }
        }

        [PSCustomObject]@{
            ComputerName = $env:COMPUTERNAME
            User = $env:USERNAME
            Date = Get-Date
            OS = $os
            CPU = [PSCustomObject]@{
                Name = if ($cpu) { $cpu.Name } else { "N/A" }
                Cores = if ($cpu) { $cpu.NumberOfCores } else { 0 }
                LogicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { 0 }
            }
            RAM_GB = if ($ram) { [math]::Round($ram.TotalPhysicalMemory / 1GB, 2) } else { 0 }
            Drives = $drives
        }
        Write-AuditLog "Exito en Get-SystemDetails"
    }
    catch {
        Write-AuditLog "Error en Get-SystemDetails: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-SystemDetails falló"; Message = $_.Exception.Message }
    }
}

function Get-InstalledSoftware {
    try {
        Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
        Select-Object DisplayName, DisplayVersion, Publisher
        Write-AuditLog "Exito en Get-InstalledSoftware"
    }
    catch {
        Write-AuditLog "Error en Get-InstalledSoftware: $($_.Exception.Message)"
        @()
    }
}

function Test-DiskUsage {
    try {
        Get-PSDrive -PSProvider FileSystem | ForEach-Object {
            $used = $_.Used
            $free = $_.Free
            $total = $used + $free

            $usedPercent = if ($total -gt 0) { ($used / $total) * 100 } else { 0 }

            [PSCustomObject]@{
                Drive = $_.Name
                UsedPercent = [math]::Round($usedPercent, 2)
                Status = if ($usedPercent -gt 90) { "CRITICAL" } else { "OK" }
            }
        }
        Write-AuditLog "Exito en Test-DiskUsage"
    }
    catch {
        Write-AuditLog "Error en Test-DiskUsage: $($_.Exception.Message)"
        @()
    }
}

# ================================
# PROCESOS
# ================================

function Test-DiskUsage {
    param([int]$Limit = 10)

    try {
        Get-Process -ErrorAction SilentlyContinue | Sort-Object CPU -Descending | Select-Object -First $Limit
        Write-AuditLog "Exito en Test-DiskUsage"
    }
    catch {
        Write-AuditLog "Error en Get-TopProcesses: $($_.Exception.Message)"
        @()
    }
}

function Test-SystemLoad {
    param([int]$ProcessCount)

    try {
        if ($ProcessCount -gt 150) { "High" } else { "Normal" }
    }
    catch {
        "Unknown"
    }
}

function Invoke-ProcessAudit {
    param([int]$Top = 5)

    try {
        $all = Get-Process -ErrorAction SilentlyContinue

        [PSCustomObject]@{
            TotalProcesses = $all.Count
            LoadStatus = Test-SystemLoad -ProcessCount $all.Count
            TopProcesses = $all | Sort-Object CPU -Descending | Select-Object -First $Top
        }
        Write-AuditLog "Exito en Invoke-ProcessAudit"
    }
    catch {
        Write-AuditLog "Error en Invoke-ProcessAudit: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Invoke-ProcessAudit falló"; Message = $_.Exception.Message }
    }
}

# ================================
# RED
# ================================

function Get-NetworkConnections {
    try {
        Get-NetTCPConnection -ErrorAction SilentlyContinue |
        Select-Object OwningProcess, LocalAddress, LocalPort, RemoteAddress, RemotePort, State
        Write-AuditLog "Exito en Get-NetworkConnections"
    }
    catch {
        Write-AuditLog "Error en Get-NetworkConnections: $($_.Exception.Message)"
        @()
    }
}

function Get-SuspiciousConnections {
    try {
        Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object {
            $_.State -eq "Established" -and
            $_.RemoteAddress -notlike "192.168*" -and
            $_.RemoteAddress -ne "127.0.0.1"
        } | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State
        Write-AuditLog "Exito en Get-SuspiciousConnections"
    }
    catch {
        Write-AuditLog "Error en Get-SuspiciousConnections: $($_.Exception.Message)"
        @()
    }
}

function Get-NetworkConfiguration {
    try {
        Get-NetIPConfiguration -ErrorAction SilentlyContinue
        Write-AuditLog "Exito en Get-NetworkConfiguration"
    }
    catch {
        Write-AuditLog "Error en Get-NetworkConfiguration: $($_.Exception.Message)"
        $null
    }
}

function Get-NetworkAdapters {
    try {
        Get-NetAdapter -ErrorAction SilentlyContinue | Select-Object Name, Status, MacAddress, LinkSpeed
        Write-AuditLog "Exito en Get-NetworkAdapters"
    }
    catch {
        Write-AuditLog "Error en Get-NetworkAdapters: $($_.Exception.Message)"
        @()
    }
}

function Get-NetworkAudit {
    param([int]$PortToTest = 80)

    try {
        [PSCustomObject]@{
            PortTest = [PSCustomObject]@{ Port = $PortToTest; IsOpen = $false; Note = "Prueba deshabilitada" }
            Connections = Get-NetworkConnections
            SuspiciousConnections = Get-SuspiciousConnections
            IPConfig = Get-NetworkConfiguration
            Adapters = Get-NetworkAdapters
        }
        Write-AuditLog "Exito en Get-NetworkAudit"
    }
    catch {
        Write-AuditLog "Error en Get-NetworkAudit: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-NetworkAudit falló"; Message = $_.Exception.Message }
    }
}

'''
function Invoke-PortScan {
    param($puertoscomunes = @(80, 443, 22, 21, 25, 135, 139, 3389, 8080))

    $open = @()
    Write-Host "Escaneando puertos..." 

    foreach ($p in $puertoscomunes) {
        Write-Host "  Probando puerto $p..." 
        try {
            $job = Start-Job -ScriptBlock { 
                param($port)
                Test-NetConnection 127.0.0.1 -Port $port -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
            } -ArgumentList $p
            
            $job | Wait-Job -Timeout 2 | Out-Null
            $result = $job | Receive-Job -ErrorAction SilentlyContinue
            Remove-Job $job -Force
            
            if ($result -and $result.TcpTestSucceeded) {
                $open += $p
                Write-Host "Puerto $p ABIERTO" 
            }
        }
        catch {
            # Error
        }
    }

    if ($open.Count -eq 0) {
        Write-Host "  No se encontraron puertos abiertos" -ForegroundColor Gray
    } else {
        Write-Host "  Puertos abiertos: $($open -join ', ')" -ForegroundColor Cyan
    }

    return $open
}
'''
# ================================
# USUARIOS y PRIVILEGIOS
# ================================

function Get-LocalUserAudit {
    try {
        $users = Get-LocalUser -ErrorAction SilentlyContinue

        $never = @()
        $active = @()

        foreach ($u in $users) {
            $obj = [PSCustomObject]@{
                Name = $u.Name
                Enabled = $u.Enabled
                LastLogon = $u.LastLogon
            }

            if (-not $u.LastLogon) { $never += $obj }
            else { $active += $obj }
        }

        [PSCustomObject]@{
            NeverLoggedOn = $never
            HasLoggedOn = $active
        }
        Write-AuditLog "Exito en Get-LocalUserAudit"
    }
    catch {
        Write-AuditLog "Error en Get-LocalUserAudit: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-LocalUserAudit falló"; Message = $_.Exception.Message }
    }
}

function Get-PrivilegeAudit {
    try {
        [PSCustomObject]@{
            Administrators = Get-LocalGroupMember -Group "Administrators" -ErrorAction SilentlyContinue
            Privileges = (whoami /priv 2>$null | Out-String)
        }
        Write-AuditLog "Exito en Get-PrivilegeAudit"

    }
    catch {
        Write-AuditLog "Error en Get-PrivilegeAudit: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-PrivilegeAudit falló"; Message = $_.Exception.Message }
    }
}

# ================================
# SEGURIDAD
# ================================

function Get-SecurityEvents {
    param([int]$MaxEvents = 50)

    try {
        Get-WinEvent -LogName Security -MaxEvents $MaxEvents -ErrorAction SilentlyContinue |
        Where-Object { $_.Id -in 4624,4625 } |
        Select-Object TimeCreated, Id, Message
        Write-AuditLog "Exito en Get-SecurityEvents"
    }
    catch {
        Write-AuditLog "Error en Get-SecurityEvents: $($_.Exception.Message)"
        @()
    }
}

function Get-FirewallStatus {
    try {
        Get-NetFirewallProfile -ErrorAction SilentlyContinue | Select-Object Name, Enabled
        Write-AuditLog "Exito en Get-FirewallStatus"
    }
    catch {
        Write-AuditLog "Error en Get-FirewallStatus: $($_.Exception.Message)"
        @()
    }
}

function Get-WindowsUpdateStatus {
    try {
        Get-HotFix -ErrorAction SilentlyContinue | Select-Object HotFixID, InstalledOn
        Write-AuditLog "Exito en Get-WindowsUpdateStatus"
    }
    catch {
        Write-AuditLog "Error en Get-WindowsUpdateStatus: $($_.Exception.Message)"
        @()
    }
}

function Get-AntivirusStatus {
    try {
        Get-MpComputerStatus -ErrorAction SilentlyContinue |
        Select-Object AMServiceEnabled, AntivirusEnabled, RealTimeProtectionEnabled
        Write-AuditLog "Exito en Get-AntivirusStatus"
    }
    catch {
        Write-AuditLog "Error en Get-AntivirusStatus: $($_.Exception.Message)"
        [PSCustomObject]@{ Status = "Defender no disponible"; Error = $_.Exception.Message }
    }
}

function Get-CriticalServices {
    $names = "WinDefend", "wuauserv", "LanmanServer"

    try {
        Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -in $names } |
        Select-Object Name, Status, StartType
        Write-AuditLog "Exito en Get-CriticalServices"
    }
    catch {
        Write-AuditLog "Error en Get-CriticalServices: $($_.Exception.Message)"
        @()
    }
}

function Get-PersistenceAudit {
    try {
        [PSCustomObject]@{
            Startup = Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue
            Registry = try {
                Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" -ErrorAction SilentlyContinue
                Write-AuditLog "Exito en Get-PersistenceAudit"
            } 
            catch {
                $null
            }
        }
    }
    catch {
        Write-AuditLog "Error en Get-PersistenceAudit: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-PersistenceAudit falló"; Message = $_.Exception.Message }
    }
}

function Get-OSVulnerabilities {
    try {
        $os = Get-ComputerInfo -ErrorAction SilentlyContinue | Select-Object OsName, OsVersion

        [PSCustomObject]@{
            OS = $os
            Findings = "Revisión básica (integración CVE futura)"
        }
            Write-AuditLog "Exito en Get-OSVulnerabilities"
    }
    catch {
        Write-AuditLog "Error en Get-OSVulnerabilities: $($_.Exception.Message)"
        [PSCustomObject]@{ Error = "Get-OSVulnerabilities falló"; Message = $_.Exception.Message }
    }
}

# ================================
# HEALTH + RISK
# ================================

function Get-SystemHealth {
    param ($Disk, $Firewall, $Processes, $Antivirus)

    $issues = @()

    try {
        if ($Disk -and ($Disk | Measure-Object UsedPercent -Maximum -ErrorAction SilentlyContinue).Maximum -gt 90) {
            $issues += "Disk critical"
        }

        if ($Firewall -and ($Firewall | Where-Object { $_.Enabled -eq $false })) {
            $issues += "Firewall disabled"
        }

        if ($Processes -and $Processes.TotalProcesses -gt 200) {
            $issues += "Too many processes"
        }

        if ($Antivirus -and $Antivirus.AntivirusEnabled -eq $false) {
            $issues += "Antivirus disabled"
        }
        Write-AuditLog "Exito en Get-SystemHealth"
    }
    catch {
        Write-AuditLog "Error en Get-SystemHealth: $($_.Exception.Message)"
        $issues += "Health check error"
    }

    if ($issues.Count -eq 0) { return "Healthy" }
    return $issues
}

function Get-RiskScore {
    param($Issues)

    try {
        if ($Issues -eq "Healthy") { return 100 }

        if ($Issues -isnot [array]) {
            $Issues = @($Issues)
        }

        $score = 100 - ($Issues.Count * 10)
        if ($score -lt 0) { $score = 0 }
        return $score
        Write-AuditLog "Exito en Get-RiskScore"
    }
    catch {
        Write-AuditLog "Error en Get-RiskScore: $($_.Exception.Message)"
        return 0
    }
}

# ================================
# FUNCIONES PARA MAIN
# ================================

function Show-SystemInfo {
    Write-Host "`n===SISTEMA===" 
    $system = Get-SystemDetails
    $software = Get-InstalledSoftware
    $disk = Test-DiskUsage
    $system | Format-List
    Write-Host "`n===SOFTWARE INSTALADO===" 
    $software | Select-Object -First 20 | Format-Table -AutoSize
    Write-Host "`n===USO DE DISCO===" 
    $disk | Format-Table -AutoSize
}

function Show-ProcessesInfo {
    Write-Host "`n===PROCESOS==="
    $process = Invoke-ProcessAudit
    Write-Host "Total Procesos: $($process.TotalProcesses)" 
    Write-Host "Estado de Carga: $($process.LoadStatus)" 
    Write-Host "`nTop Procesos (CPU):"
    $process.TopProcesses | Format-Table -AutoSize
}

function Show-NetworkInfo {
    Write-Host "`n===RE==="
    $network = Get-NetworkAudit
    Write-Host "Puerto 80 abierto: $($network.PortTest.IsOpen)" 
    Write-Host "`n===CONEXIONES SOSPECHOSAS==="
    $network.SuspiciousConnections | Format-Table -AutoSize
}

function Show-SecurityInfo {
    Write-Host "`n===SEGURIDAD==="
    $firewall = Get-FirewallStatus
    $antivirus = Get-AntivirusStatus
    $services = Get-CriticalServices
    $persistence = Get-PersistenceAudit
    $vulns = Get-OSVulnerabilities

    Write-Host "===FIREWALL==="
    $firewall | Format-Table -AutoSize
    Write-Host "===ANTIVIRUS==="
    $antivirus | Format-List
    Write-Host "===SERVICIOS CRÍTICOS==="
    $services | Format-Table -AutoSize
    Write-Host "===VULNERABILIDADES OS==="
    $vulns | Format-List
}

function Show-UsersPrivileges {
    Write-Host "`n===USUARIOS Y PRIVILEGIOS==="
    $users = Get-LocalUserAudit
    $privs = Get-PrivilegeAudit

    Write-Host "===USUARIOS QUE NUNCA HAN INICIADO SESION===" 
    $users.NeverLoggedOn | Format-Table -AutoSize
    Write-Host "===USUARIOS ACTIVOS===" 
    $users.HasLoggedOn | Format-Table -AutoSize
    Write-Host "===ADMINISTRADORES==="
    $privs.Administrators | Format-Table -AutoSize
}

function Show-SystemHealthInfo {
    Write-Host "`n=== SALUD DEL SISTEMA ==="
    $disk = Test-DiskUsage
    $firewall = Get-FirewallStatus
    $process = Invoke-ProcessAudit
    $antivirus = Get-AntivirusStatus
    $health = Get-SystemHealth -Disk $disk -Firewall $firewall -Processes $process -Antivirus $antivirus
    $risk = Get-RiskScore -Issues $health

    Write-Host "Health Status:" 
    if ($health -eq "Healthy") {
        Write-Host "  $health" 
    } else {
        Write-Host "  $health" 
    }
    Write-Host "`nRisk Score: $risk / 100" 
}

# ================================
# MAIN FUNCTION
# ================================

function Invoke-SystemAudit {
    param(
        [string]$OutputPath,
        [switch]$SkipPortScan
    )

    Write-AuditLog "Audit started"

    $system = Get-SystemDetails
    $process = Invoke-ProcessAudit
    $network = Get-NetworkAudit
    $users = Get-LocalUserAudit
    $events = Get-SecurityEvents
    $firewall = Get-FirewallStatus
    $updates = Get-WindowsUpdateStatus
    $services = Get-CriticalServices
    $disk = Test-DiskUsage
    $antivirus = Get-AntivirusStatus
    $persistence = Get-PersistenceAudit
    $privs = Get-PrivilegeAudit
    $software = Get-InstalledSoftware
    $ports = @()
    $vulns = Get-OSVulnerabilities
    $health = Get-SystemHealth -Disk $disk -Firewall $firewall -Processes $process -Antivirus $antivirus
    $risk = Get-RiskScore -Issues $health

    $result = [PSCustomObject]@{
        System = $system
        Processes = $process
        Network = $network
        Users = $users
        SecurityEvents = $events
        Firewall = $firewall
        Updates = $updates
        Services = $services
        Disk = $disk
        Antivirus = $antivirus
        Persistence = $persistence
        Privileges = $privs
        Software = $software
        OpenPorts = $ports
        Vulnerabilities = $vulns
        Health = $health
        RiskScore = $risk
    }

    if ($OutputPath) {
        try {
            Write-Host "`nGuardando JSON..." -ForegroundColor Gray
            $result | ConvertTo-Json -Depth 5 | Out-File $OutputPath -Encoding UTF8 -Force
            Write-Host "  JSON guardado en: $OutputPath" -ForegroundColor Green

            $htmlPath = [System.IO.Path]::ChangeExtension($OutputPath, "html")
            Write-Host "Guardando HTML..." -ForegroundColor Gray
            
            $html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>System Audit Report</title>
<style>
body { font-family: Arial; background:#0f172a; color:#e2e8f0; padding:20px; }
h1 { color:#38bdf8; }
.box { background:#1e293b; padding:15px; border-radius:10px; margin-bottom:15px; }
</style>
</head>
<body>
<h1>System Audit Report</h1>
<div class="box">
<h2>Risk Score</h2>
<h3>$($result.RiskScore) / 100</h3>
</div>
<div class="box">
<h2>Health</h2>
<pre>$($result.Health)</pre>
</div>
<div class="box">
<h2>System</h2>
<p><strong>Computer:</strong> $($result.System.ComputerName)</p>
<p><strong>User:</strong> $($result.System.User)</p>
<p><strong>OS:</strong> $($result.System.OS.OSName)</p>
<p><strong>RAM:</strong> $($result.System.RAM_GB) GB</p>
</div>
</body>
</html>
"@
            $html | Out-File -Encoding UTF8 $htmlPath -Force
            Write-Host "  HTML guardado en: $htmlPath" -ForegroundColor Green

            Write-AuditLog "Reportes generados: JSON=$OutputPath, HTML=$htmlPath"
        }
        catch {
            Write-AuditLog "Error al generar reportes: $($_.Exception.Message)"
            Write-Host "Error al generar reportes: $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    Write-AuditLog "Auditoria completa"
    return $result
}

# ================================
# EXPORT
# ================================
Export-ModuleMember -Function *