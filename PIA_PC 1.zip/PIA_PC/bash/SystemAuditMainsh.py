import argparse
from scrapy.crawler import CrawlerProcess
from SystemAuditModulesh import NoticiasSpider

def main():
    parser = argparse.ArgumentParser(description="Buscador de noticias mejorado")

    parser.add_argument("url")
    parser.add_argument("terminos")
    parser.add_argument("--formato", default="json")
    parser.add_argument("--output", default="resultados")
    parser.add_argument("--max-depth", default=2)
    parser.add_argument("--modo", default="flexible", choices=["flexible", "estricto"])

    args = parser.parse_args()

    archivo_salida = f"{args.output}.{args.formato}"

    print(f"URL: {args.url}")
    print(f"Terminos: {args.terminos}")
    print(f"Archivo: {archivo_salida}")
    print(f"Profundidad: {args.max_depth}")
    print(f"Modo: {args.modo}")

    process = CrawlerProcess(settings={
        "FEEDS": {
            archivo_salida: {
                "format": args.formato,
                "encoding": "utf-8",
                "indent": 4,
            }
        },
        "LOG_LEVEL": "ERROR",
        "CONCURRENT_REQUESTS": 16,
        "DOWNLOAD_DELAY": 0.5,
    })

    process.crawl(
        NoticiasSpider,
        url=args.url,
        terminos=args.terminos.split(","),
        max_depth=int(args.max_depth),
        modo=args.modo
    )

    process.start()


if __name__ == "__main__":
    main()