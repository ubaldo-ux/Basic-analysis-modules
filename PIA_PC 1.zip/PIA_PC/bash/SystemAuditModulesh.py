import scrapy
from scrapy.crawler import CrawlerProcess
from urllib.parse import urlparse, urljoin
import argparse
import re
import unicodedata
from collections import defaultdict


# =========================
# UTILIDADES
# =========================

def normalizar(texto):
    texto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in texto if not unicodedata.combining(c)).upper()


def coincide(texto, terminos, modo="flexible"):
    texto_norm = normalizar(texto)

    if modo == "estricto":
        return any(re.search(rf"\b{re.escape(t)}\b", texto_norm) for t in terminos)
    return any(t in texto_norm for t in terminos)


def es_texto_util(texto):
    if not texto:
        return False

    texto = texto.strip()
    return len(texto) > 20


def url_valida(url):
    malos = ["login", "signup", "contact", "#", "javascript"]
    extensiones_malas = [".pdf", ".zip", ".rar", ".7z", ".exe", ".msi", 
                         ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg",
                         ".mp3", ".mp4", ".avi", ".mkv", ".doc", ".docx", 
                         ".xls", ".xlsx", ".ppt", ".pptx"]

    if any(b in url for b in malos):
        return False

    for ext in extensiones_malas:
        if url.endswith(ext):
            return False

    return True


def contar_ocurrencias(texto, terminos):
    texto = normalizar(texto)
    return sum(texto.count(t) for t in terminos)


def calcular_score(texto, titulo, terminos):
    score = 0

    if titulo and any(t in normalizar(titulo) for t in terminos):
        score += 5

    score += contar_ocurrencias(texto, terminos)

    return score


# =========================
# SPIDER
# =========================

class NoticiasSpider(scrapy.Spider):
    name = "noticias"

    def __init__(self, url, terminos, max_depth=2, modo="flexible", results=None, **kwargs):
        super().__init__(**kwargs)

        self.start_urls = [url]
        self.allowed_domains = [urlparse(url).netloc]

        self.terminos = [normalizar(t.strip()) for t in terminos]
        self.max_depth = int(max_depth)
        self.modo = modo

        self.visitadas = set()
        self.resultados = []
        self.stats = defaultdict(int)

    def parse(self, response):
        depth = response.meta.get("depth", 0)
            
        espacio = "  " * depth
        print(f"{espacio}[{depth}] VISITANDO: {response.url}")

        content_type = response.headers.get('Content-Type', b'').decode('utf-8').lower()
        if 'html' not in content_type:
            print(f"{espacio}  -> IGNORADO (no HTML): {content_type}")
            return

        if response.url in self.visitadas:
            print(f"{espacio}  -> YA VISITADA")
            return

        self.visitadas.add(response.url)
        self.stats["paginas_visitadas"] += 1
        print(f"{espacio}  -> PROCESANDO (encuentros: {self.stats['matches']})")

        titulo = response.css("title::text").get()
        descripcion = response.css('meta[name="description"]::attr(content)').get()

        # =========================
        # EXTRAER CONTENIDO
        # =========================

        for elemento in response.css("h1, h2, h3, p"):
            texto = elemento.css("::text").get()

            if not es_texto_util(texto):
                continue

            limpio = texto.strip()

            if coincide(limpio, self.terminos, self.modo):
                score = calcular_score(limpio, titulo, self.terminos)

                data = {
                    "texto": limpio,
                    "url": response.url,
                    "titulo": titulo,
                    "descripcion": descripcion,
                    "depth": depth,
                    "score": score
                }

                self.resultados.append(data)
                self.stats["matches"] += 1

                yield data

        # =========================
        # FOLLOW LINKS
        # =========================

        if depth >= self.max_depth:
            return

        for link in response.css("a::attr(href)").getall():
            url_absoluta = urljoin(response.url, link)

            extensiones_ignorar = ['.pdf', '.zip', '.rar', '.jpg', 
            '.jpeg', '.png', '.gif', '.mp3', '.mp4', '.doc',
            '.docx', '.xls', '.xlsx']

            if any(url_absoluta.lower().endswith(ext) for ext in extensiones_ignorar):
                continue

            if url_valida(url_absoluta) and urlparse(url_absoluta).netloc == self.allowed_domains[0]:
                yield response.follow(
                    url_absoluta,
                    callback=self.parse,
                    meta={"depth": depth + 1}
                )

    def closed(self, reason):
        # ordenar por relevancia
        self.resultados.sort(key=lambda x: x["score"], reverse=True)

        print("\n==============================")
        print(f"Resultados encontrados: {len(self.resultados)}")
        print(f"Páginas visitadas: {self.stats['paginas_visitadas']}")
        print("==============================")

        # mostrar top 5
        print("\nTOP RESULTADOS:")
        for r in self.resultados[:5]:
            print(f"- ({r['score']}) {r['texto'][:80]}...")
        print("==============================\n")
